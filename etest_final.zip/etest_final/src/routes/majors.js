'use strict';

const express = require('express');
const router = express.Router();

// CSDL mẫu chứa thông tin ngành DỮ LIỆU THẬT cho các trường lớn
// ĐỀU PHẢI map ID với dữ liệu QS_SUBJECTS chuẩn (cs, eng, bus, law, med, sci, art, soc, arch, data) 
// để Step 3 (Trường mục tiêu) hoạt động!
const MAJORS_DB = {
  // University of Melbourne (120)
  120: [ 
    { id: 'cs', nameVI: 'Khoa học Máy tính & IT (Computer Science)' },
    { id: 'data', nameVI: 'Khoa học Dữ liệu (Data Science)' },
    { id: 'med', nameVI: 'Y khoa & Nha khoa (Medicine & Dentistry)' },
    { id: 'law', nameVI: 'Luật (Law)' },
    { id: 'bus', nameVI: 'Thương mại & Quản lý (Commerce & Business)' },
    { id: 'art', nameVI: 'Nghệ thuật & Nhân văn (Arts)' },
    { id: 'soc', nameVI: 'Khoa học Xã hội & Giáo dục (Social Sciences)' },
    { id: 'eng', nameVI: 'Kỹ thuật & Công nghệ (Engineering)' },
    { id: 'arch', nameVI: 'Kiến trúc & Hệ thống Môi trường (Architecture)' },
    { id: 'sci', nameVI: 'Khoa học Tự nhiên (Science)' }
  ],
  // RMIT Vietnam (9113)
  9113: [ 
    { id: 'cs', nameVI: 'Công nghệ Thông tin & Phần mềm (IT/Software)' },
    { id: 'data', nameVI: 'Trí tuệ Nhân tạo & Khoa học Dữ liệu (Data Science & AI)' },
    { id: 'bus', nameVI: 'Quản trị Kinh doanh & Logistics (Business & Logistics)' },
    { id: 'soc', nameVI: 'Truyền thông Chuyên nghiệp (Professional Comm)' },
    { id: 'art', nameVI: 'Thiết kế & Nghệ thuật số (Design & Digital Arts)' },
    { id: 'arch', nameVI: 'Kiến trúc (Architecture)' }
  ],
  // MIT (101)
  101: [ 
    { id: 'cs', nameVI: 'EECS (Điện & Khoa học máy tính)' },
    { id: 'data', nameVI: 'Toán học & Khoa học Dữ liệu (Math & Data)' },
    { id: 'sci', nameVI: 'Vật lý Ứng dụng & Hóa học (Applied Sciences)' },
    { id: 'bus', nameVI: 'Quản trị Công nghệ Sloan (Sloan Business)' },
    { id: 'arch', nameVI: 'Kiến trúc (Architecture)' },
    { id: 'eng', nameVI: 'Kỹ thuật Cơ khí & Hàng không (Engineering)' }
  ]
};

router.get('/', (req, res) => {
  try {
    const uniId = parseInt(req.query.uniId, 10);
    if (!uniId) {
      return res.status(400).json({ error: 'Missing uniId parameter' });
    }

    const majors = MAJORS_DB[uniId] || [
       { id: 'cs', nameVI: 'Khoa học máy tính (Computer Science)' },
       { id: 'bus', nameVI: 'Kinh tế & Quản lý (Business)' },
       { id: 'eng', nameVI: 'Kỹ thuật & Công nghệ (Engineering)' },
       { id: 'sci', nameVI: 'Khoa học Tự nhiên (Science)' }
    ];

    // Tạo độ trễ giả để thấy hiệu ứng loading trên frontend
    setTimeout(() => {
      return res.json(majors);
    }, 400);

  } catch (error) {
    console.error('[GET /api/majors] Error:', error);
    res.status(500).json({ error: 'Lỗi server' });
  }
});

module.exports = router;
