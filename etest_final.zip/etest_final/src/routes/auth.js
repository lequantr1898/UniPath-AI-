'use strict';

const express  = require('express');
const bcrypt   = require('bcryptjs');
const pool     = require('../db');
const router   = express.Router();

/**
 * POST /api/auth/login
 * Body: { email, password }
 */
router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  try {
    const [rows] = await pool.query(
      'SELECT id, email, password_hash, role, full_name, is_active FROM users WHERE email = ? LIMIT 1',
      [email.trim().toLowerCase()]
    );

    const user = rows[0];
    if (!user || !user.is_active) {
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    // Node.js bcryptjs supports $2a$ or $2b$, but PHP generates $2y$.
    // They are algorithmically the same, so we can string-replace $2y$ to $2a$.
    const hash = user.password_hash.replace(/^\$2y\$/, '$2a$');

    const match = await bcrypt.compare(password, hash);
    if (!match) {
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    // Update last_login
    await pool.query('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);

    // Store session
    req.session.uid   = user.id;
    req.session.role  = user.role;
    req.session.name  = user.full_name;
    req.session.email = user.email;

    const { password_hash, ...safeUser } = user;
    return res.json({ ok: true, user: safeUser });
  } catch (err) {
    console.error('[auth/login]', err);
    return res.status(500).json({ error: 'Server error.' });
  }
});

/**
 * POST /api/auth/logout
 */
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

/**
 * GET /api/auth/me
 * Returns current session user info (or 401 if not logged in).
 */
router.get('/me', (req, res) => {
  if (!req.session.uid) {
    return res.status(401).json({ error: 'Not logged in.' });
  }
  return res.json({
    uid:   req.session.uid,
    role:  req.session.role,
    name:  req.session.name,
    email: req.session.email,
  });
});

module.exports = router;
