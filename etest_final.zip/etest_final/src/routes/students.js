'use strict';

const express          = require('express');
const pool             = require('../db');
const { normalize }    = require('../scoreNormalizer');
const { requireLogin } = require('../middleware/auth');
const router           = express.Router();

// ─── Student profile & scores ────────────────────────────────────────────────

/**
 * GET /api/students
 * Admin only. Query params: search, limit, offset
 */
router.get('/', requireLogin('admin'), async (req, res) => {
  const search = req.query.search  || '';
  const limit  = Math.min(parseInt(req.query.limit  || '50', 10), 200);
  const offset = parseInt(req.query.offset || '0', 10);
  const like   = `%${search}%`;

  try {
    const [rows] = await pool.query(
      `SELECT u.id, u.email, u.full_name, u.created_at,
              p.school_name, p.grade_year,
              (SELECT norm_value FROM student_scores
               WHERE user_id=u.id AND score_type='GPA'
               ORDER BY created_at DESC LIMIT 1) gpa_norm,
              (SELECT norm_value FROM student_scores
               WHERE user_id=u.id AND score_type='IELTS'
               ORDER BY created_at DESC LIMIT 1) ielts_norm,
              (SELECT COUNT(*) FROM student_targets WHERE user_id=u.id) target_count
       FROM users u LEFT JOIN student_profiles p ON p.user_id=u.id
       WHERE u.role='student' AND (u.full_name LIKE ? OR u.email LIKE ?)
       ORDER BY u.created_at DESC
       LIMIT ? OFFSET ?`,
      [like, like, limit, offset]
    );
    res.json(rows);
  } catch (err) {
    console.error('[GET /students]', err);
    res.status(500).json({ error: 'Server error.' });
  }
});

/**
 * GET /api/students/:id
 * Returns profile + latest scores. Admin can access any; student can access own.
 */
router.get('/:id', requireLogin(), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  // Students can only view their own profile
  if (req.session.role !== 'admin' && req.session.uid !== id) {
    return res.status(403).json({ error: 'Forbidden.' });
  }

  try {
    const [[profile]] = await pool.query(
      `SELECT u.id, u.email, u.full_name, u.created_at, u.last_login,
              p.gender, p.dob, p.phone, p.nationality, p.school_name, p.grade_year, p.bio
       FROM users u LEFT JOIN student_profiles p ON p.user_id=u.id
       WHERE u.id=?`,
      [id]
    );
    if (!profile) return res.status(404).json({ error: 'Student not found.' });

    const [scoreRows] = await pool.query(
      `SELECT s1.score_type, s1.raw_value, s1.raw_scale, s1.norm_value, s1.date_taken
       FROM student_scores s1
       INNER JOIN (
         SELECT score_type, MAX(created_at) mx
         FROM student_scores WHERE user_id=? GROUP BY score_type
       ) s2 ON s1.score_type=s2.score_type AND s1.created_at=s2.mx
       WHERE s1.user_id=?`,
      [id, id]
    );

    const scores = {};
    for (const r of scoreRows) scores[r.score_type] = r;
    profile.scores = scores;

    res.json(profile);
  } catch (err) {
    console.error('[GET /students/:id]', err);
    res.status(500).json({ error: 'Server error.' });
  }
});

/**
 * PUT /api/students/:id/profile
 * Body: { full_name?, gender?, dob?, phone?, nationality?, school_name?, grade_year?, bio? }
 */
router.put('/:id/profile', requireLogin(), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (req.session.role !== 'admin' && req.session.uid !== id) {
    return res.status(403).json({ error: 'Forbidden.' });
  }

  const { full_name, gender, dob, phone, nationality, school_name, grade_year, bio } = req.body || {};

  try {
    if (full_name) {
      await pool.query('UPDATE users SET full_name=? WHERE id=?', [full_name, id]);
    }
    await pool.query(
      `INSERT INTO student_profiles (user_id,gender,dob,phone,nationality,school_name,grade_year,bio)
       VALUES (?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE gender=?,dob=?,phone=?,nationality=?,school_name=?,grade_year=?,bio=?`,
      [
        id, gender||null, dob||null, phone||null, nationality||null, school_name||null, grade_year||null, bio||null,
            gender||null, dob||null, phone||null, nationality||null, school_name||null, grade_year||null, bio||null,
      ]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('[PUT /students/:id/profile]', err);
    res.status(500).json({ error: 'Server error.' });
  }
});

/**
 * POST /api/students/:id/scores
 * Body: { score_type, raw_value, raw_scale, date_taken? }
 */
router.post('/:id/scores', requireLogin(), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (req.session.role !== 'admin' && req.session.uid !== id) {
    return res.status(403).json({ error: 'Forbidden.' });
  }

  const { score_type, raw_value, raw_scale, date_taken } = req.body || {};
  if (!score_type || raw_value == null || !raw_scale) {
    return res.status(400).json({ error: 'score_type, raw_value, and raw_scale are required.' });
  }

  try {
    const norm = normalize(score_type, parseFloat(raw_value), raw_scale);
    await pool.query(
      `INSERT INTO student_scores (user_id,score_type,raw_value,raw_scale,norm_value,date_taken)
       VALUES (?,?,?,?,?,?)`,
      [id, score_type, parseFloat(raw_value), raw_scale, norm, date_taken || null]
    );
    res.status(201).json({ ok: true, norm_value: norm });
  } catch (err) {
    console.error('[POST /students/:id/scores]', err);
    res.status(500).json({ error: 'Server error.' });
  }
});

// ─── Target Calculator ────────────────────────────────────────────────────────

async function getLatestScores(uid) {
  const [rows] = await pool.query(
    `SELECT s1.score_type, s1.raw_value, s1.norm_value
     FROM student_scores s1
     INNER JOIN (
       SELECT score_type, MAX(created_at) mx
       FROM student_scores WHERE user_id=? GROUP BY score_type
     ) s2 ON s1.score_type=s2.score_type AND s1.created_at=s2.mx
     WHERE s1.user_id=?`,
    [uid, uid]
  );
  const out = {};
  for (const r of rows) out[r.score_type] = r;
  return out;
}

async function analyzeTargets(uid, majorId) {
  const [reqs] = await pool.query(
    'SELECT * FROM major_requirements WHERE major_id=?',
    [majorId]
  );
  const scores  = await getLatestScores(uid);
  const result  = [];

  for (const r of reqs) {
    const cur  = scores[r.score_type]?.norm_value ?? null;
    const tgt  = r.min_score;
    const gap  = cur !== null ? +(tgt - cur).toFixed(3) : null;
    const pct  = cur ? Math.min(100, Math.round(cur / tgt * 100)) : 0;
    let status;
    if (cur === null)   status = 'missing';
    else if (gap <= 0)  status = 'achieved';
    else if (gap < 0.3) status = 'close';
    else                status = 'gap';

    result.push({
      type: r.score_type, current: cur, target: tgt,
      raw_target: r.raw_min, raw_scale: r.raw_scale,
      gap, pct, status, notes: r.notes,
    });
  }
  return result;
}

/**
 * GET /api/students/:id/targets
 */
router.get('/:id/targets', requireLogin(), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (req.session.role !== 'admin' && req.session.uid !== id) {
    return res.status(403).json({ error: 'Forbidden.' });
  }

  try {
    const [rows] = await pool.query(
      `SELECT t.*, m.name major_name, m.faculty,
              u.name uni_name, u.qs_rank, u.logo_initial,
              c.flag, c.name country_name
       FROM student_targets t
       JOIN majors m      ON m.id=t.major_id
       JOIN universities u ON u.id=m.university_id
       JOIN countries c    ON c.id=u.country_id
       WHERE t.user_id=? ORDER BY u.qs_rank`,
      [id]
    );
    res.json(rows);
  } catch (err) {
    console.error('[GET /students/:id/targets]', err);
    res.status(500).json({ error: 'Server error.' });
  }
});

/**
 * POST /api/students/:id/targets
 * Body: { major_id }
 * Runs gap analysis and saves results.
 */
router.post('/:id/targets', requireLogin(), async (req, res) => {
  const uid     = parseInt(req.params.id, 10);
  const majorId = parseInt((req.body || {}).major_id, 10);
  if (req.session.role !== 'admin' && req.session.uid !== uid) {
    return res.status(403).json({ error: 'Forbidden.' });
  }
  if (!majorId) return res.status(400).json({ error: 'major_id is required.' });

  try {
    const analysis = await analyzeTargets(uid, majorId);

    await pool.query(
      'DELETE FROM student_targets WHERE user_id=? AND major_id=?',
      [uid, majorId]
    );

    for (const r of analysis) {
      const dbStatus = r.status === 'achieved' ? 'achieved'
                     : r.current !== null       ? 'in_progress'
                                                : 'not_started';
      await pool.query(
        `INSERT INTO student_targets (user_id,major_id,score_type,current_norm,target_norm,status)
         VALUES (?,?,?,?,?,?)`,
        [uid, majorId, r.type, r.current, r.target, dbStatus]
      );
    }

    res.json({ ok: true, analysis });
  } catch (err) {
    console.error('[POST /students/:id/targets]', err);
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
