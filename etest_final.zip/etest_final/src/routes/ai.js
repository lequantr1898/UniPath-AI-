'use strict';

const express = require('express');
const router = express.Router();
const { generateChatResponse } = require('../services/aiService');

/**
 * POST /api/ai/chat
 * Expects JSON: { "prompt": "user message here" }
 */
router.post('/chat', async (req, res) => {
  try {
    const { prompt, context } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required in the request body.' });
    }

    const responseText = await generateChatResponse(prompt, context);
    res.json({ reply: responseText });
  } catch (error) {
    console.error('[POST /api/ai/chat] Error:', error);
    res.status(500).json({ error: 'AI generation failed: ' + error.message });
  }
});

module.exports = router;
