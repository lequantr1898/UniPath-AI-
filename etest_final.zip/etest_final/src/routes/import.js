'use strict';

const express           = require('express');
const multer            = require('multer');
const { parse }         = require('csv-parse');
const bcrypt            = require('bcryptjs');
const fs                = require('fs');
const path              = require('path');
const pool              = require('../db');
const { normalize, generatePassword } = require('../scoreNormalizer');
const { requireLogin }  = require('../middleware/auth');
const router            = express.Router();

// Store uploads in OS temp dir, auto-cleanup after processing
const upload = multer({ dest: require('os').tmpdir() });

// CSV template content (port of BulkImporter::templateCSV)
const TEMPLATE_HEADER = 'ho_ten,email,gioi_tinh,ngay_sinh,sdt,truong_hoc,lop,gpa_10,ielts,toefl,sat,act';
const TEMPLATE_ROWS = [
  'Phạm Tuấn Đạt,phamtuandat@gmail.com,Nam,2006-03-15,0912345678,THPT Chuyên Lê Hồng Phong,Lớp 12,8.5,6.5,,,',
  'Nguyễn Thị Lan Anh,nguyenthilananh@gmail.com,Nữ,2006-07-22,0987654321,THPT Chuyên Hùng Vương,Lớp 12,9.1,7.0,,,',
  'Trần Minh Khoa,tranminhkhoa@gmail.com,Nam,2005-11-08,0909090909,THPT Chuyên Nguyễn Huệ,Lớp 12,7.8,6.0,,1150,',
  'Lê Thị Thu Hương,lethithuhuong@gmail.com,Nữ,2006-01-30,0933333333,THPT Marie Curie,Lớp 12,8.9,7.5,,,',
  'Vũ Hoàng Nam,vuhoangnam@gmail.com,Nam,2005-09-14,0944444444,THPT Chuyên Lê Quý Đôn,Lớp 12,8.2,6.0,95,,',
  'Đặng Ngọc Bảo Châu,dangngocdbaochau@gmail.com,Nữ,2006-05-18,0955555555,THPT Chuyên Trần Đại Nghĩa,Lớp 12,9.3,7.5,,,',
  'Bùi Công Thành,buicongthanh@gmail.com,Nam,2005-12-25,0966666666,THPT Chuyên Lê Hồng Phong,Lớp 11,7.5,,80,,',
  'Hoàng Thị Minh Tú,hoangthiminhtu@gmail.com,Nữ,2006-04-10,0977777777,THPT Gia Định,Lớp 12,8.7,6.5,,,',
  'Phan Văn Hải,phanvanhai@gmail.com,Nam,2005-08-03,0988888888,THPT Chuyên Hà Nội Amsterdam,Lớp 12,9.0,7.0,,1300,',
  'Ngô Thị Quỳnh Như,ngothiquynhnhu@gmail.com,Nữ,2006-06-27,0999999999,THPT Chuyên Võ Thị Sáu,Lớp 12,8.4,6.5,,,',
];

/**
 * GET /api/import/template
 * Download the CSV template file.
 */
router.get('/template', requireLogin('admin'), (_req, res) => {
  const content = '\uFEFF' + TEMPLATE_HEADER + '\n' + TEMPLATE_ROWS.join('\n') + '\n';
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="hoc_vien_mau.csv"');
  res.send(content);
});

/**
 * POST /api/import/csv
 * Multipart form-data with field "file" containing a CSV.
 */
router.post('/csv', requireLogin('admin'), upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded. Use field name "file".' });
  }

  const adminId  = req.session.uid;
  const filePath = req.file.path;
  const fileName = req.file.originalname;

  let ok = 0, fail = 0, dup = 0;
  const errors = [];

  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8').replace(/^\uFEFF/, '');

    await new Promise((resolve, reject) => {
      parse(fileContent, { columns: true, trim: true, skip_empty_lines: true },
        async (err, records) => {
          if (err) return reject(err);

          for (let i = 0; i < records.length; i++) {
            const row = records[i];
            const rowNum = i + 2; // 1-indexed, +1 for header

            try {
              const result = await processRow(row);
              if (result === 'ok')  ok++;
              else if (result === 'dup') dup++;
              else { fail++; errors.push(`Row ${rowNum}: ${result}`); }
            } catch (e) {
              fail++;
              errors.push(`Row ${rowNum}: ${e.message}`);
            }
          }
          resolve();
        }
      );
    });

    // Write import log
    await pool.query(
      `INSERT INTO import_logs (admin_id,filename,total_rows,success_rows,failed_rows,error_details)
       VALUES (?,?,?,?,?,?)`,
      [adminId, fileName, ok + fail + dup, ok, fail, errors.join('\n')]
    );

    res.json({ ok, fail, dup, errors });
  } catch (err) {
    console.error('[POST /import/csv]', err);
    res.status(500).json({ error: 'Import failed: ' + err.message });
  } finally {
    fs.unlink(filePath, () => {}); // cleanup temp file
  }
});

// ─── Helpers ─────────────────────────────────────────────────────────────────

function col(row, keys) {
  for (const k of keys) {
    const val = row[k];
    if (val !== undefined && val.trim() !== '') return val.trim();
  }
  return '';
}

function parseDate(v) {
  if (!v) return null;
  const ts = Date.parse(v);
  if (isNaN(ts)) return null;
  return new Date(ts).toISOString().slice(0, 10); // YYYY-MM-DD
}

async function processRow(line) {
  // Normalise keys to lowercase
  const row = {};
  for (const [k, v] of Object.entries(line)) row[k.toLowerCase()] = v;

  const name  = col(row, ['ho_ten','full_name','name','họ tên']);
  const email = col(row, ['email']).toLowerCase();
  if (!name || !email) return 'missing_name_email';

  // Check duplicate
  const [existing] = await pool.query('SELECT id FROM users WHERE email=?', [email]);
  if (existing.length > 0) return 'dup';

  // Auto-password
  const password = generatePassword(name);
  const hash     = await bcrypt.hash(password, 10);

  // Create user
  const [userResult] = await pool.query(
    `INSERT INTO users (email, password_hash, role, full_name) VALUES (?,?,?,?)`,
    [email, hash, 'student', name]
  );
  const uid = userResult.insertId;
  if (!uid) return 'create_failed';

  // Create profile
  await pool.query(
    `INSERT INTO student_profiles (user_id,gender,dob,phone,nationality,school_name,grade_year)
     VALUES (?,?,?,?,?,?,?)
     ON DUPLICATE KEY UPDATE gender=?,dob=?,phone=?,nationality=?,school_name=?,grade_year=?`,
    [
      uid,
      col(row,['gioi_tinh','gender']) || null,
      parseDate(col(row,['ngay_sinh','dob','birthday'])),
      col(row,['sdt','phone']) || null,
      col(row,['quoc_tich','nationality']) || null,
      col(row,['truong_hoc','school','school_name']) || null,
      col(row,['lop','grade','grade_year']) || null,
      // ON DUPLICATE KEY values
      col(row,['gioi_tinh','gender']) || null,
      parseDate(col(row,['ngay_sinh','dob','birthday'])),
      col(row,['sdt','phone']) || null,
      col(row,['quoc_tich','nationality']) || null,
      col(row,['truong_hoc','school','school_name']) || null,
      col(row,['lop','grade','grade_year']) || null,
    ]
  );

  // Import scores
  const SCORE_MAP = [
    { type: 'GPA',   keys: ['gpa_10','gpa10','gpa'], scale: '/10' },
    { type: 'IELTS', keys: ['ielts'],                scale: '/9.0' },
    { type: 'TOEFL', keys: ['toefl','toefl_ibt'],    scale: '/120' },
    { type: 'SAT',   keys: ['sat'],                  scale: '/1600' },
    { type: 'ACT',   keys: ['act'],                  scale: '/36' },
  ];

  for (const { type, keys, scale } of SCORE_MAP) {
    const raw = col(row, keys);
    if (raw !== '' && !isNaN(parseFloat(raw))) {
      const rawVal = parseFloat(raw);
      const norm   = normalize(type, rawVal, scale);
      await pool.query(
        `INSERT INTO student_scores (user_id,score_type,raw_value,raw_scale,norm_value,date_taken)
         VALUES (?,?,?,?,?,CURDATE())`,
        [uid, type, rawVal, scale, norm]
      );
    }
  }

  return 'ok';
}

module.exports = router;
