'use strict';

const { GoogleGenerativeAI } = require('@google/generative-ai');

let genAI = null;

function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'your_gemini_api_key_here') {
    return null;
  }
  if (!genAI) {
    genAI = new GoogleGenerativeAI(apiKey);
  }
  return genAI;
}

async function generateChatResponse(prompt, context = {}) {
  const ai = getGenAI();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured in .env');
  }

  let sysPrompt = `You are UniPath AI — an intelligent study abroad AI assistant, integrated into the UniPath system.

**ASSISTANT SCOPE:** You are ONLY allowed to answer questions belonging to the following topics:
- Study abroad, visas, scholarships, tuition fees, living costs abroad
- Universities and colleges domestic and international
- Majors, training programs, entry requirements
- Test scores (GPA, IELTS, TOEFL, SAT, ACT, etc.)
- Application profiles, essays, letters of recommendation
- Study abroad preparation roadmaps
- Student information in the system (if provided)

**REFUSAL RULES:** If the question is NOT related to the above topics (e.g., poetry, cooking, coding, sports, entertainment, politics, etc.), politely refuse and remind the user to ask relevant questions. Example: "Sorry, I can only assist with matters related to study abroad and education. Do you have any questions about studying abroad, schools, or majors?"

**STYLE:** Reply in English, be professional, concise, and always use markdown when necessary.`;
  if (context && Object.keys(context).length > 0) {
    sysPrompt += `\n\nStudent detailed information (use this to optimize your reply):
- Name: ${context.name || 'Student'}
- Grade: ${context.grade || 'Not provided'}
- GPA: ${context.gpa || 'Not provided'}
- IELTS: ${context.ielts || 'Not provided'}
- Intended Major: ${context.major || 'Not provided'}
- Target School: ${context.targetSchool || 'Not provided'}`;
  }

  try {
    const model = ai.getGenerativeModel({ 
        model: "gemini-2.5-flash",
        systemInstruction: sysPrompt,
        tools: [{ googleSearch: {} }] 
    });
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (err) {
    console.warn("Search grounding failed or unconfigured for this key, falling back to base model. Error:", err.message);
    const fallbackModel = ai.getGenerativeModel({ 
        model: "gemini-2.5-flash",
        systemInstruction: sysPrompt
    });
    const result = await fallbackModel.generateContent(prompt);
    return result.response.text();
  }
}

module.exports = {
  generateChatResponse
};
