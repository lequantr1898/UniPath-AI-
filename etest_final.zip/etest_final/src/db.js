'use strict';
require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host:               process.env.DB_HOST     || 'localhost',
  database:           process.env.DB_NAME     || 'etest_db',
  user:               process.env.DB_USER     || 'root',
  password:           process.env.DB_PASS     || '',
  charset:            'utf8mb4',
  waitForConnections: true,
  connectionLimit:    10,
  queueLimit:         0,
});

module.exports = pool;
