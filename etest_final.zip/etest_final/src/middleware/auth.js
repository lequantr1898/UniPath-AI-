'use strict';

/**
 * Auth middleware — equivalent to Auth::requireLogin() / Auth::check()
 */

function requireLogin(role = '') {
  return (req, res, next) => {
    if (!req.session || !req.session.uid) {
      return res.status(401).json({ error: 'Unauthorized — please log in.' });
    }
    if (role && req.session.role !== role) {
      return res.status(403).json({ error: `Forbidden — requires role: ${role}` });
    }
    next();
  };
}

module.exports = { requireLogin };
