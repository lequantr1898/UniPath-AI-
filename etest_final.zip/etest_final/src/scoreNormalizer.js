'use strict';

/**
 * ScoreNormalizer — port of ScoreNormalizer.php
 * Normalizes raw scores to /4.0 scale.
 */

const ACCENT_MAP = {
  'à':'a','á':'a','ả':'a','ã':'a','ạ':'a',
  'ă':'a','ắ':'a','ằ':'a','ẳ':'a','ẵ':'a','ặ':'a',
  'â':'a','ấ':'a','ầ':'a','ẩ':'a','ẫ':'a','ậ':'a',
  'è':'e','é':'e','ẻ':'e','ẽ':'e','ẹ':'e',
  'ê':'e','ế':'e','ề':'e','ể':'e','ễ':'e','ệ':'e',
  'ì':'i','í':'i','ỉ':'i','ĩ':'i','ị':'i',
  'ò':'o','ó':'o','ỏ':'o','õ':'o','ọ':'o',
  'ô':'o','ố':'o','ồ':'o','ổ':'o','ỗ':'o','ộ':'o',
  'ơ':'o','ớ':'o','ờ':'o','ở':'o','ỡ':'o','ợ':'o',
  'ù':'u','ú':'u','ủ':'u','ũ':'u','ụ':'u',
  'ư':'u','ứ':'u','ừ':'u','ử':'u','ữ':'u','ự':'u',
  'ỳ':'y','ý':'y','ỷ':'y','ỹ':'y','ỵ':'y','đ':'d',
  'À':'A','Á':'A','Ả':'A','Ã':'A','Ạ':'A',
  'Ă':'A','Ắ':'A','Ằ':'A','Ẳ':'A','Ẵ':'A','Ặ':'A',
  'Â':'A','Ấ':'A','Ầ':'A','Ẩ':'A','Ẫ':'A','Ậ':'A',
  'È':'E','É':'E','Ẻ':'E','Ẽ':'E','Ẹ':'E',
  'Ê':'E','Ế':'E','Ề':'E','Ể':'E','Ễ':'E','Ệ':'E',
  'Ì':'I','Í':'I','Ỉ':'I','Ĩ':'I','Ị':'I',
  'Ò':'O','Ó':'O','Ỏ':'O','Õ':'O','Ọ':'O',
  'Ô':'O','Ố':'O','Ồ':'O','Ổ':'O','Ỗ':'O','Ộ':'O',
  'Ơ':'O','Ớ':'O','Ờ':'O','Ở':'O','Ỡ':'O','Ợ':'O',
  'Ù':'U','Ú':'U','Ủ':'U','Ũ':'U','Ụ':'U',
  'Ư':'U','Ứ':'U','Ừ':'U','Ử':'U','Ữ':'U','Ự':'U',
  'Ỳ':'Y','Ý':'Y','Ỷ':'Y','Ỹ':'Y','Ỵ':'Y','Đ':'D',
};

function removeAccents(str) {
  return str.replace(/[^\u0000-\u007E]/g, ch => ACCENT_MAP[ch] || ch);
}

const SAT_TABLE = [
  [1570,4.0],[1540,3.95],[1510,3.9],[1480,3.85],[1450,3.8],
  [1420,3.75],[1390,3.7],[1360,3.65],[1330,3.6],[1300,3.55],
  [1260,3.5],[1220,3.45],[1180,3.4],[1140,3.35],[1100,3.3],
  [1060,3.2],[1010,3.1],[960,3.0],[900,2.8],[400,2.0],
];

const ACT_TABLE = [
  [36,4.0],[35,3.97],[34,3.93],[33,3.9],[32,3.87],[31,3.83],
  [30,3.8],[29,3.75],[28,3.7],[27,3.65],[26,3.6],[25,3.55],
  [24,3.5],[22,3.3],[20,3.1],[18,2.9],[1,2.0],
];

function lookupTable(table, value) {
  for (const [threshold, norm] of table) {
    if (value >= threshold) return norm;
  }
  return 2.0;
}

function gpa(v, scale) {
  if (scale.includes('10'))  return +((v / 10 * 4).toFixed(3));
  if (scale.includes('100')) return +((v / 100 * 4).toFixed(3));
  return +(Math.min(v, 4.0).toFixed(3));
}

/**
 * Normalize a raw score to /4.0
 * @param {string} type  GPA | IELTS | TOEFL | SAT | ACT | GMAT | GRE
 * @param {number} value raw score
 * @param {string} scale e.g. '/10', '/9.0', '/120'
 * @returns {number} normalized score (3 decimal places)
 */
function normalize(type, value, scale = '') {
  switch (type.toUpperCase()) {
    case 'GPA':   return gpa(value, scale);
    case 'IELTS': return +((value / 9.0 * 4.0).toFixed(3));
    case 'TOEFL': return +((value / 120.0 * 4.0).toFixed(3));
    case 'SAT':   return lookupTable(SAT_TABLE, value);
    case 'ACT':   return lookupTable(ACT_TABLE, value);
    case 'GMAT':  return +(((value - 200) / 600 * 4.0).toFixed(3));
    case 'GRE':   return +(((value - 260) / 80 * 4.0).toFixed(3));
    default:      return +(value.toFixed(3));
  }
}

/**
 * Generate password from full name.
 * e.g. "Phạm Tuấn Đạt" → "tuandat123"
 */
function generatePassword(fullName) {
  const parts = fullName.trim().split(/\s+/);
  const given = parts.slice(-2).join('');
  const ascii  = removeAccents(given);
  const clean  = ascii.replace(/[^a-zA-Z]/g, '').toLowerCase();
  return clean + '123';
}

module.exports = { normalize, generatePassword, removeAccents };
