# Etest Target System v3
### Academic Benchmark & Study Abroad Planner

---

## Cài đặt nhanh

### 1. Tạo database
```bash
mysql -u root -p < sql/etest_db.sql
```

### 2. Chỉnh kết nối DB
Sửa `config/Database.php`:
```php
private string $host     = 'localhost';
private string $db_name  = 'etest_db';
private string $username = 'root';
private string $password = '';
```

### 3. Deploy
Copy vào `htdocs` (XAMPP) hoặc `www` (Laragon):
```
C:\xampp\htdocs\EtestTarget\
```
Truy cập: `http://localhost/EtestTarget/public/`

---

## Tài khoản demo

| Role    | Email              | Mật khẩu  |
|---------|--------------------|-----------|
| Admin   | admin@etest.vn     | Admin@123 |
| Student | demo@student.vn    | demo123   |

> **Lưu ý:** Không có chức năng Đăng ký. Tài khoản do Admin tạo qua Bulk Import.

---

## Quy tắc mật khẩu tự động (Bulk Import)

Khi Admin upload file CSV, hệ thống tự tạo mật khẩu từ họ tên:

| Họ và tên          | Mật khẩu tự động |
|--------------------|-----------------|
| Phạm Tuấn Đạt      | `tuandat123`    |
| Nguyễn Thị Lan Anh | `lananh123`     |
| Đặng Ngọc Bảo Châu | `baochau123`    |
| Bùi Công Thành     | `congthanh123`  |

**Công thức:** 2 từ cuối của họ tên (bỏ dấu, chữ thường) + `123`

---

## Cấu trúc project

```
/EtestTarget
├── config/
│   └── Database.php          — Kết nối MySQL (PDO)
├── classes/
│   ├── Auth.php               — Đăng nhập (không có đăng ký)
│   ├── Student.php            — Quản lý học viên & điểm
│   ├── ScoreNormalizer.php   — Quy đổi GPA/IELTS/TOEFL/SAT/ACT → 4.0
│   ├── BulkImporter.php      — Import CSV, tạo tài khoản tự động
│   └── Student.php            — TargetCalculator tích hợp
├── public/
│   └── index.html             — Full app (Admin + Student)
├── sql/
│   └── etest_db.sql           — Schema + Seed data
├── hoc_vien_mau.csv           — File mẫu 10 học viên Việt Nam
└── README.md
```

---

## Tính năng

### Admin
- Dashboard tổng quan (KPI: học viên, mục tiêu, đã đạt, cần cải thiện)
- Danh sách học viên: tìm kiếm, lọc, phân trang
- **Bulk Import** (4 bước): Upload CSV → Auto-map cột → Preview mật khẩu → Xác nhận
- **Lộ trình học viên**: xem Gap Analysis + điểm chuẩn hóa + ghi chú tư vấn (có thể ghim)

### Student (tài khoản do Admin tạo)
- Dashboard: điểm đã quy đổi, mục tiêu đang theo dõi, ghi chú từ Etest
- Hồ sơ & Điểm số: cập nhật thông tin + nhập điểm (live conversion)
- Tìm Trường & Ngành: 15 trường Top QS, lọc theo quốc gia
- **Gap Analysis**: chọn trường/ngành → xem khoảng cách → lưu mục tiêu
- Mục tiêu của tôi: theo dõi tiến độ từng mục tiêu

### Quy đổi điểm
| Chứng chỉ | Thang gốc | Công thức |
|-----------|-----------|-----------|
| GPA (VN)  | /10       | ÷ 10 × 4  |
| IELTS     | /9.0      | ÷ 9 × 4   |
| TOEFL iBT | /120      | ÷ 120 × 4 |
| SAT       | /1600     | Bảng concordance |
| ACT       | /36       | Bảng concordance |
| GMAT      | /800      | (x−200) ÷ 600 × 4 |

---

## File mẫu CSV

Tải `hoc_vien_mau.csv` — có sẵn 10 học viên mẫu để test Bulk Import.

Hoặc trong app: Admin → Bulk Import → "Tải file mẫu CSV"
