(function () {
  'use strict';

  const rootEl = document.getElementById('ai-widget-root');
  if (!rootEl) return;

  // Create Shadow DOM to encapsulate Bootstrap CSS
  const shadow = rootEl.attachShadow({ mode: 'open' });

  // Add Bootstrap CSS into Shadow DOM using link tags to avoid @import block issues
  const bsCss = document.createElement('link');
  bsCss.rel = 'stylesheet';
  bsCss.href = 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css';
  shadow.appendChild(bsCss);

  const bsIcons = document.createElement('link');
  bsIcons.rel = 'stylesheet';
  bsIcons.href = 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css';
  shadow.appendChild(bsIcons);

  const style = document.createElement('style');
  style.textContent = `
    :host {
      --primary-color: #6366f1;
      --primary-gradient: linear-gradient(135deg, #6366f1, #8b5cf6);
      font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }

    #widget-container {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }

    .chat-btn {
      width: 60px;
      height: 60px;
      background: var(--primary-gradient);
      border: none;
      border-radius: 50%;
      color: white;
      font-size: 28px;
      box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }
    
    .chat-btn:hover {
      transform: scale(1.08);
      box-shadow: 0 6px 20px rgba(99, 102, 241, 0.6);
    }

    .chat-panel {
      width: 360px;
      height: 520px;
      background: #f8f9fa;
      border-radius: 16px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      margin-bottom: 16px;
      opacity: 0;
      transform: translateY(20px) scale(0.95);
      transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      pointer-events: none;
      border: 1px solid rgba(0,0,0,0.08);
    }

    .chat-panel.show {
      opacity: 1;
      transform: translateY(0) scale(1);
      pointer-events: auto;
    }

    .chat-header {
      background: var(--primary-gradient);
      color: white;
      padding: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .chat-header .d-flex { gap: 12px; }

    .header-icon {
      width: 40px;
      height: 40px;
      background: rgba(255,255,255,0.25);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
    }

    .header-info h6 { margin: 0; font-weight: 700; font-size: 16px; }
    .header-info small { opacity: 0.85; font-size: 12px; }

    .chat-close {
      background: transparent;
      border: none;
      color: rgba(255,255,255,0.8);
      font-size: 24px;
      cursor: pointer;
      transition: color 0.2s;
    }
    .chat-close:hover { color: white; }

    .chat-body {
      flex: 1;
      padding: 16px;
      overflow-y: auto;
      background: #ffffff;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .msg-wrapper {
      display: flex;
      gap: 10px;
      align-items: flex-end;
      max-width: 85%;
    }

    .msg-wrapper.me {
      align-self: flex-end;
      flex-direction: row-reverse;
    }

    .msg-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: #e9ecef;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      flex-shrink: 0;
    }
    .msg-wrapper.ai .msg-avatar { background: var(--primary-color); color: white; }
    .msg-wrapper.me .msg-avatar { background: #6c757d; color: white; }

    .msg-bubble {
      padding: 12px 16px;
      border-radius: 16px;
      font-size: 14px;
      line-height: 1.5;
      word-wrap: break-word;
    }

    .msg-wrapper.ai .msg-bubble {
      background: #f1f3f5;
      color: #212529;
      border-bottom-left-radius: 4px;
    }

    .msg-wrapper.me .msg-bubble {
      background: var(--primary-color);
      color: white;
      border-bottom-right-radius: 4px;
    }

    .chat-footer {
      padding: 14px;
      background: white;
      border-top: 1px solid #dee2e6;
    }

    .input-group {
      background: #f8f9fa;
      border: 1px solid #ced4da;
      border-radius: 24px;
      padding: 4px;
      transition: border-color 0.2s;
    }
    
    .input-group:focus-within {
      border-color: var(--primary-color);
      box-shadow: 0 0 0 0.2rem rgba(99, 102, 241, 0.15);
    }

    .chat-input {
      border: none;
      background: transparent;
      padding: 8px 16px;
      font-size: 14.5px;
      resize: none;
      max-height: 100px;
    }
    .chat-input:focus { outline: none; box-shadow: none; }

    .send-btn {
      width: 38px;
      height: 38px;
      border-radius: 50%;
      background: var(--primary-color);
      color: white;
      border: none;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: opacity 0.2s;
    }
    .send-btn:hover { opacity: 0.85; }

    .typing-indicator {
      display: flex;
      gap: 4px;
      padding: 6px 4px;
    }
    .typing-indicator span {
      width: 6px;
      height: 6px;
      background: #adb5bd;
      border-radius: 50%;
      animation: typing 1.4s infinite ease-in-out both;
    }
    .typing-indicator span:nth-child(1) { animation-delay: -0.32s; }
    .typing-indicator span:nth-child(2) { animation-delay: -0.16s; }
    @keyframes typing {
      0%, 80%, 100% { transform: scale(0); }
      40% { transform: scale(1); }
    }

    .unread-badge {
      position: absolute;
      top: 0;
      right: 0;
      background: #dc3545;
      color: white;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      font-size: 11px;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid white;
      transform: translate(20%, -20%);
    }

    /* Scrollbar */
    .chat-body::-webkit-scrollbar { width: 6px; }
    .chat-body::-webkit-scrollbar-track { background: transparent; }
    .chat-body::-webkit-scrollbar-thumb { background: #ced4da; border-radius: 10px; }
  `;

  // HTML Structure
  const container = document.createElement('div');
  container.id = 'widget-container';
  container.innerHTML = `
    <div class="chat-panel" id="aiwPanel">
      <div class="chat-header">
        <div class="d-flex align-items-center">
          <div class="header-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg></div>
          <div class="header-info">
            <h6>UniPath AI</h6>
            <small>Study Abroad Advisor</small>
          </div>
        </div>
        <button class="chat-close" id="aiwClose"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>
      </div>
      
      <div class="chat-body" id="aiwMsgs">
        <!-- Messages will appear here -->
      </div>
      
      <div class="chat-footer">
        <div class="input-group d-flex align-items-end">
          <textarea class="form-control chat-input" id="aiwInput" rows="1" placeholder="Ask about schools, scholarships..."></textarea>
          <button class="send-btn ms-2 mb-1 me-1" id="aiwSend"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-left:-2px"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg></button>
        </div>
      </div>
    </div>
    
    <div class="position-relative">
      <button class="chat-btn" id="aiwToggle">
        <svg id="icon-chat" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"/></svg>
        <svg id="icon-close" style="display:none;" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
      </button>
      <div class="unread-badge" id="aiwBadge" style="display:none">1</div>
    </div>
  `;

  shadow.appendChild(style);
  shadow.appendChild(container);

  // ── Logic ──
  const panel   = shadow.getElementById('aiwPanel');
  const toggle  = shadow.getElementById('aiwToggle');
  const closeBtn= shadow.getElementById('aiwClose');
  const msgs    = shadow.getElementById('aiwMsgs');
  const input   = shadow.getElementById('aiwInput');
  const sendBtn = shadow.getElementById('aiwSend');
  const badge   = shadow.getElementById('aiwBadge');

  let isOpen = false;

  // Initial greeting (Sử dụng innerHTML thay vì hàm addAIMsg bị escape)
  msgs.innerHTML += `
    <div class="msg-wrapper ai">
      <div class="msg-avatar"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg></div>
      <div class="msg-bubble">
        Hello! 👋 I am <strong>UniPath AI</strong>.<br><br>
        I use the analytics system technology to assist you with:<br>
        • 🎓 Study abroad profile advising<br>
        • 🏫 Finding suitable schools & scholarships<br>
        • 📈 Score preparation guidance<br><br>
        How can I help you today?
      </div>
    </div>
  `;
  setBadge(true);

  const iconChat = shadow.getElementById('icon-chat');
  const iconClose = shadow.getElementById('icon-close');

  toggle.addEventListener('click', () => {
    isOpen = !isOpen;
    if (isOpen) {
      panel.classList.add('show');
      iconChat.style.display = 'none';
      iconClose.style.display = 'block';
      setBadge(false);
      setTimeout(() => input.focus(), 300);
    } else {
      panel.classList.remove('show');
      iconChat.style.display = 'block';
      iconClose.style.display = 'none';
    }
  });

  closeBtn.addEventListener('click', () => {
    isOpen = false;
    panel.classList.remove('show');
    iconChat.style.display = 'block';
    iconClose.style.display = 'none';
  });

  // Auto-resize textarea
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 100) + 'px';
  });

  sendBtn.addEventListener('click', sendMsg);
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMsg();
    }
  });

  async function sendMsg() {
    const txt = input.value.trim();
    if (!txt) return;
    input.value = '';
    input.style.height = 'auto';

    addUserMsg(txt);

    // Typing
    const tid = 'typ_' + Date.now();
    msgs.innerHTML += `
      <div class="msg-wrapper ai" id="${tid}">
        <div class="msg-avatar"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg></div>
        <div class="msg-bubble">
          <div class="typing-indicator"><span></span><span></span><span></span></div>
        </div>
      </div>
    `;
    scrollToBottom();

    try {
      const context = getPageContext();
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: txt, context })
      });

      shadow.getElementById(tid)?.remove();

      if (res.ok) {
        const data = await res.json();
        addAIMsg(data.reply || 'Sorry, I cannot answer right now.');
      } else {
        addAIMsg('Sorry, an error occurred. Please try again later.');
      }
    } catch (e) {
      shadow.getElementById(tid)?.remove();
      addAIMsg('<span class="text-danger">⚠️ Server connection error.</span>');
    }

    if (!isOpen) setBadge(true);
  }

  function addUserMsg(txt) {
    const safeTxt = escHtml(txt);
    msgs.innerHTML += `
      <div class="msg-wrapper me">
        <div class="msg-avatar"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <div class="msg-bubble">${safeTxt}</div>
      </div>
    `;
    scrollToBottom();
  }

  function addAIMsg(txt) {
    // Basic Markdown formatting
    let formatted = String(txt)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br>');
      
     // Support simple headers
     formatted = formatted.replace(/^### (.*$)/gim, '<strong>$1</strong>')
                          .replace(/^## (.*$)/gim, '<strong>$1</strong>');
                          
    msgs.innerHTML += `
      <div class="msg-wrapper ai">
        <div class="msg-avatar"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg></div>
        <div class="msg-bubble">${formatted}</div>
      </div>
    `;
    scrollToBottom();
  }

  function escHtml(s) {
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
  }

  function scrollToBottom() {
    setTimeout(() => {
      msgs.scrollTop = msgs.scrollHeight;
    }, 50);
  }

  function setBadge(show) {
    badge.style.display = show ? 'flex' : 'none';
  }

  function getPageContext() {
    try {
      if (window.USER) {
        return {
          name: window.USER.name,
          grade: window.USER.grade,
          gpa: window.USER.gpa4,
          ielts: window.USER.ielts,
          major: window.USER.interests,
          targetSchool: window.USER.country
        };
      }
    } catch (e) {}
    return {};
  }

})();
