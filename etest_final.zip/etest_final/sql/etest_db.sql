-- ============================================================
--  Etest Target System — Database Schema + Seed Data
--  Chạy: mysql -u root -p < sql/etest_db.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS etest_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE etest_db;

CREATE TABLE countries (
    id   INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(5)   NOT NULL,
    flag VARCHAR(10)  DEFAULT '🌐'
);

CREATE TABLE universities (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    country_id    INT NOT NULL,
    name          VARCHAR(255) NOT NULL,
    qs_rank       INT,
    website       VARCHAR(255),
    logo_initial  VARCHAR(5),
    description   TEXT,
    FOREIGN KEY (country_id) REFERENCES countries(id)
);

CREATE TABLE majors (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    university_id INT NOT NULL,
    name          VARCHAR(255) NOT NULL,
    faculty       VARCHAR(255),
    degree_level  ENUM('Bachelor','Master','PhD') DEFAULT 'Bachelor',
    FOREIGN KEY (university_id) REFERENCES universities(id)
);

CREATE TABLE major_requirements (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    major_id    INT NOT NULL,
    score_type  ENUM('GPA','IELTS','TOEFL','SAT','ACT','GMAT','GRE') NOT NULL,
    min_score   FLOAT NOT NULL COMMENT 'Normalized /4.0',
    raw_min     FLOAT,
    raw_scale   VARCHAR(20),
    notes       VARCHAR(255),
    FOREIGN KEY (major_id) REFERENCES majors(id)
);

CREATE TABLE users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    email         VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          ENUM('admin','student') NOT NULL DEFAULT 'student',
    full_name     VARCHAR(255),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login    TIMESTAMP NULL,
    is_active     TINYINT(1) DEFAULT 1
);

CREATE TABLE student_profiles (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL UNIQUE,
    gender       ENUM('Male','Female','Other','Nam','Nữ','Khác') DEFAULT NULL,
    dob          DATE,
    phone        VARCHAR(30),
    nationality  VARCHAR(100),
    school_name  VARCHAR(255),
    grade_year   VARCHAR(50),
    bio          TEXT,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE student_scores (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    score_type  ENUM('GPA','IELTS','TOEFL','SAT','ACT','GMAT','GRE') NOT NULL,
    raw_value   FLOAT NOT NULL,
    raw_scale   VARCHAR(20) NOT NULL,
    norm_value  FLOAT NOT NULL COMMENT 'Normalized /4.0',
    date_taken  DATE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE student_targets (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT NOT NULL,
    major_id      INT NOT NULL,
    score_type    ENUM('GPA','IELTS','TOEFL','SAT','ACT','GMAT','GRE') NOT NULL,
    current_norm  FLOAT,
    target_norm   FLOAT NOT NULL,
    gap           FLOAT GENERATED ALWAYS AS (ROUND(target_norm - IFNULL(current_norm,0), 3)) STORED,
    status        ENUM('not_started','in_progress','achieved') DEFAULT 'not_started',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)  REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (major_id) REFERENCES majors(id) ON DELETE CASCADE
);

CREATE TABLE admin_notes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    admin_id    INT NOT NULL,
    student_id  INT NOT NULL,
    note        TEXT NOT NULL,
    is_pinned   TINYINT(1) DEFAULT 0,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id)   REFERENCES users(id),
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE import_logs (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    admin_id      INT NOT NULL,
    filename      VARCHAR(255),
    total_rows    INT DEFAULT 0,
    success_rows  INT DEFAULT 0,
    failed_rows   INT DEFAULT 0,
    error_details TEXT,
    imported_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id)
);

-- ── SEED: Countries ──
INSERT INTO countries (name, code, flag) VALUES
('United States','US','🇺🇸'),('United Kingdom','UK','🇬🇧'),('Switzerland','CH','🇨🇭'),
('Singapore','SG','🇸🇬'),('Australia','AU','🇦🇺'),('Canada','CA','🇨🇦'),
('Japan','JP','🇯🇵'),('China','CN','🇨🇳');

-- ── SEED: Universities ──
INSERT INTO universities (country_id,name,qs_rank,logo_initial) VALUES
(1,'Massachusetts Institute of Technology',1,'MIT'),
(2,'Imperial College London',2,'ICL'),
(2,'University of Oxford',3,'OXF'),
(1,'Harvard University',4,'HAR'),
(1,'Stanford University',5,'STN'),
(2,'University of Cambridge',6,'CAM'),
(3,'ETH Zürich',7,'ETH'),
(4,'National University of Singapore',8,'NUS'),
(1,'UC Berkeley',10,'UCB'),
(1,'Cornell University',13,'COR'),
(1,'Yale University',14,'YAL'),
(1,'Princeton University',16,'PRI'),
(6,'University of Toronto',25,'UOT'),
(5,'University of Melbourne',33,'UOM'),
(7,'University of Tokyo',28,'UTK');

-- ── SEED: Majors ──
INSERT INTO majors (university_id,name,faculty) VALUES
(1,'Computer Science & AI','Engineering'),(1,'Electrical Engineering','Engineering'),
(2,'Biomedical Engineering','Engineering'),(2,'Computing','Engineering'),
(3,'Engineering Science','Engineering'),(3,'Law','Law'),(3,'Economics & Management','Social Sciences'),
(4,'Computer Science','SEAS'),(4,'Business Administration (MBA)','HBS'),
(5,'Computer Science','Engineering'),(5,'Data Science','Engineering'),
(6,'Natural Sciences','Physical Sciences'),(6,'Mathematics','Physical Sciences'),
(7,'Mechanical Engineering','Engineering'),(7,'Computer Science','CS Dept'),
(8,'Computer Engineering','Engineering'),(8,'Business Administration','NUS Business'),
(9,'EECS','Engineering'),
(13,'Computer Science','Arts & Science'),
(14,'Engineering','Melbourne Engineering'),(14,'Business','Melbourne Business');

-- ── SEED: Major Requirements ──
INSERT INTO major_requirements (major_id,score_type,min_score,raw_min,raw_scale) VALUES
(1,'GPA',3.9,3.9,'/4.0'),(1,'IELTS',3.78,8.5,'/9.0'),(1,'TOEFL',3.67,110,'/120'),(1,'SAT',3.9,1540,'/1600'),
(2,'GPA',3.85,3.85,'/4.0'),(2,'IELTS',3.56,8.0,'/9.0'),
(3,'GPA',3.7,3.7,'/4.0'),(3,'IELTS',3.33,7.5,'/9.0'),
(4,'GPA',3.75,3.75,'/4.0'),(4,'IELTS',3.33,7.5,'/9.0'),
(5,'GPA',3.8,3.8,'/4.0'),(5,'IELTS',3.33,7.5,'/9.0'),
(6,'GPA',3.9,3.9,'/4.0'),(6,'IELTS',3.56,8.0,'/9.0'),
(7,'GPA',3.75,3.75,'/4.0'),(7,'IELTS',3.33,7.5,'/9.0'),
(8,'GPA',3.9,3.9,'/4.0'),(8,'IELTS',3.33,7.5,'/9.0'),(8,'TOEFL',3.33,100,'/120'),(8,'SAT',3.88,1510,'/1600'),
(9,'GPA',3.7,3.7,'/4.0'),(9,'GMAT',3.6,730,'/800'),(9,'IELTS',3.56,8.0,'/9.0'),
(10,'GPA',3.9,3.9,'/4.0'),(10,'IELTS',3.33,7.5,'/9.0'),(10,'SAT',3.9,1500,'/1600'),
(11,'GPA',3.85,3.85,'/4.0'),(11,'IELTS',3.33,7.5,'/9.0'),
(12,'GPA',3.85,3.85,'/4.0'),(12,'IELTS',3.33,7.5,'/9.0'),
(13,'GPA',3.9,3.9,'/4.0'),(13,'IELTS',3.56,8.0,'/9.0'),
(14,'GPA',3.8,3.8,'/4.0'),(14,'IELTS',3.33,7.5,'/9.0'),
(15,'GPA',3.8,3.8,'/4.0'),(15,'IELTS',3.33,7.5,'/9.0'),
(16,'GPA',3.5,3.5,'/4.0'),(16,'IELTS',3.11,7.0,'/9.0'),(16,'TOEFL',3.0,90,'/120'),
(17,'GPA',3.4,3.4,'/4.0'),(17,'IELTS',2.89,6.5,'/9.0'),
(18,'GPA',3.8,3.8,'/4.0'),(18,'IELTS',3.33,7.5,'/9.0'),
(19,'GPA',3.6,3.6,'/4.0'),(19,'IELTS',3.11,7.0,'/9.0'),
(20,'GPA',3.3,3.3,'/4.0'),(20,'IELTS',2.89,6.5,'/9.0'),
(21,'GPA',3.25,3.25,'/4.0'),(21,'IELTS',2.89,6.5,'/9.0');

-- ── SEED: Admin account (password: Admin@123) ──
INSERT INTO users (email, password_hash, role, full_name) VALUES
('admin@etest.vn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Etest Admin');

-- ── SEED: Demo student (password: demo123) ──
INSERT INTO users (email, password_hash, role, full_name) VALUES
('demo@student.vn', '$2y$10$TKh8H1.PfbuNg369q8aFRe5yP4yFIcfFTqD.oe1OaXvzq1KUOYxa', 'student', 'Nguyễn Văn Demo');

INSERT INTO student_profiles (user_id, gender, school_name, grade_year, nationality) VALUES
(2, 'Nam', 'THPT Chuyên Lê Hồng Phong', 'Lớp 12', 'Vietnamese');

INSERT INTO student_scores (user_id, score_type, raw_value, raw_scale, norm_value, date_taken) VALUES
(2, 'GPA',  8.5, '/10',  3.400, '2024-06-01'),
(2, 'IELTS', 6.5, '/9.0', 2.889, '2024-08-15');
