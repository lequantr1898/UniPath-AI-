require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');

async function test() {
  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  console.log('Testing gemini-2.5-flash WITH googleSearch...');
  try {
    const m1 = genAI.getGenerativeModel({ model: 'gemini-2.5-flash', tools: [{ googleSearch: {} }] });
    const res = await m1.generateContent("What is the current exact tuition fee for RMIT Vietnam Computer Science? Search the web.");
    console.log("Success: m1");
    // Print out the grounding citations if any exist
    console.log(res.response.text().slice(0, 80) + '...');
    const candidates = res.response.candidates;
    if (candidates && candidates[0] && candidates[0].groundingMetadata) {
      console.log("Grounding metadata found!");
    } else {
      console.log("No grounding metadata.");
    }
  } catch (e) {
    console.log("m1 fail:", e.message);
  }
}
test();
