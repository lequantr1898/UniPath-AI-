<?php
require_once __DIR__ . '/ScoreNormalizer.php';

class Student {
    private PDO $conn;

    public function __construct(PDO $conn) {
        $this->conn = $conn;
    }

    public function getProfile(int $uid): array {
        $stmt = $this->conn->prepare(
            "SELECT u.id, u.email, u.full_name, u.created_at, u.last_login,
                    p.gender, p.dob, p.phone, p.nationality, p.school_name, p.grade_year, p.bio
             FROM users u LEFT JOIN student_profiles p ON p.user_id=u.id
             WHERE u.id=:id"
        );
        $stmt->execute([':id' => $uid]);
        $profile = $stmt->fetch() ?: [];
        $profile['scores'] = $this->getLatestScores($uid);
        return $profile;
    }

    public function getLatestScores(int $uid): array {
        $stmt = $this->conn->prepare(
            "SELECT s1.score_type, s1.raw_value, s1.raw_scale, s1.norm_value, s1.date_taken
             FROM student_scores s1
             INNER JOIN (
                 SELECT score_type, MAX(created_at) mx FROM student_scores WHERE user_id=:uid GROUP BY score_type
             ) s2 ON s1.score_type=s2.score_type AND s1.created_at=s2.mx
             WHERE s1.user_id=:uid2"
        );
        $stmt->execute([':uid' => $uid, ':uid2' => $uid]);
        $out = [];
        foreach ($stmt->fetchAll() as $r) $out[$r['score_type']] = $r;
        return $out;
    }

    public function addScore(int $uid, string $type, float $raw, string $scale): void {
        $norm = ScoreNormalizer::normalize($type, $raw, $scale);
        $this->conn->prepare(
            "INSERT INTO student_scores (user_id,score_type,raw_value,raw_scale,norm_value,date_taken)
             VALUES (:uid,:type,:raw,:scale,:norm,CURDATE())"
        )->execute([':uid'=>$uid,':type'=>$type,':raw'=>$raw,':scale'=>$scale,':norm'=>$norm]);
    }

    public function updateProfile(int $uid, array $data): void {
        if (!empty($data['full_name']))
            $this->conn->prepare("UPDATE users SET full_name=:n WHERE id=:id")->execute([':n'=>$data['full_name'],':id'=>$uid]);

        $this->conn->prepare(
            "INSERT INTO student_profiles (user_id,gender,dob,phone,nationality,school_name,grade_year,bio)
             VALUES (:uid,:g,:d,:p,:nat,:sc,:gr,:bio)
             ON DUPLICATE KEY UPDATE gender=:g,dob=:d,phone=:p,nationality=:nat,school_name=:sc,grade_year=:gr,bio=:bio"
        )->execute([
            ':uid'=>$uid,':g'=>$data['gender']??null,':d'=>$data['dob']??null,
            ':p'=>$data['phone']??null,':nat'=>$data['nationality']??null,
            ':sc'=>$data['school_name']??null,':gr'=>$data['grade_year']??null,':bio'=>$data['bio']??null,
        ]);
    }

    public function getAll(string $search='', int $limit=50, int $offset=0): array {
        $like="%{$search}%";
        $stmt=$this->conn->prepare(
            "SELECT u.id,u.email,u.full_name,u.created_at,
                    p.school_name,p.grade_year,
                    (SELECT norm_value FROM student_scores WHERE user_id=u.id AND score_type='GPA' ORDER BY created_at DESC LIMIT 1) gpa_norm,
                    (SELECT norm_value FROM student_scores WHERE user_id=u.id AND score_type='IELTS' ORDER BY created_at DESC LIMIT 1) ielts_norm,
                    (SELECT COUNT(*) FROM student_targets WHERE user_id=u.id) target_count
             FROM users u LEFT JOIN student_profiles p ON p.user_id=u.id
             WHERE u.role='student' AND (u.full_name LIKE :s OR u.email LIKE :s2)
             ORDER BY u.created_at DESC LIMIT :lim OFFSET :off"
        );
        $stmt->bindValue(':s',$like);$stmt->bindValue(':s2',$like);
        $stmt->bindValue(':lim',$limit,PDO::PARAM_INT);$stmt->bindValue(':off',$offset,PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}

// ─────────────────────────────────────
class TargetCalculator {
    private PDO $conn;

    public function __construct(PDO $conn) { $this->conn = $conn; }

    public function analyze(int $uid, int $majorId): array {
        $reqs  = $this->conn->prepare("SELECT * FROM major_requirements WHERE major_id=:m")->execute([':m'=>$majorId]) ? [] : [];
        $stmt  = $this->conn->prepare("SELECT * FROM major_requirements WHERE major_id=:m");
        $stmt->execute([':m'=>$majorId]);
        $reqs  = $stmt->fetchAll();
        $scores = $this->getScores($uid);
        $result = [];
        foreach ($reqs as $r) {
            $cur  = $scores[$r['score_type']]['norm_value'] ?? null;
            $tgt  = $r['min_score'];
            $gap  = $cur !== null ? round($tgt - $cur, 3) : null;
            $st   = $cur===null?'missing':($gap<=0?'achieved':($gap<0.3?'close':'gap'));
            $result[] = ['type'=>$r['score_type'],'current'=>$cur,'target'=>$tgt,'raw_target'=>$r['raw_min'],'raw_scale'=>$r['raw_scale'],'gap'=>$gap,'pct'=>$cur?min(100,round($cur/$tgt*100)):0,'status'=>$st,'notes'=>$r['notes']];
        }
        return $result;
    }

    public function saveTargets(int $uid, int $majorId): void {
        $this->conn->prepare("DELETE FROM student_targets WHERE user_id=:u AND major_id=:m")->execute([':u'=>$uid,':m'=>$majorId]);
        foreach ($this->analyze($uid, $majorId) as $r) {
            $this->conn->prepare(
                "INSERT INTO student_targets (user_id,major_id,score_type,current_norm,target_norm,status) VALUES (:u,:m,:t,:c,:g,:s)"
            )->execute([':u'=>$uid,':m'=>$majorId,':t'=>$r['type'],':c'=>$r['current'],':g'=>$r['target'],':s'=>$r['status']==='achieved'?'achieved':($r['current']!==null?'in_progress':'not_started')]);
        }
    }

    public function getTargets(int $uid): array {
        $stmt=$this->conn->prepare(
            "SELECT t.*,m.name major_name,m.faculty,u.name uni_name,u.qs_rank,u.logo_initial,c.flag,c.name country_name
             FROM student_targets t JOIN majors m ON m.id=t.major_id JOIN universities u ON u.id=m.university_id JOIN countries c ON c.id=u.country_id
             WHERE t.user_id=:uid ORDER BY u.qs_rank"
        );
        $stmt->execute([':uid'=>$uid]);
        return $stmt->fetchAll();
    }

    private function getScores(int $uid): array {
        $stmt=$this->conn->prepare(
            "SELECT s1.score_type,s1.raw_value,s1.norm_value FROM student_scores s1
             INNER JOIN (SELECT score_type,MAX(created_at) mx FROM student_scores WHERE user_id=:u GROUP BY score_type) s2
             ON s1.score_type=s2.score_type AND s1.created_at=s2.mx WHERE s1.user_id=:u2"
        );
        $stmt->execute([':u'=>$uid,':u2'=>$uid]);
        $out=[];foreach($stmt->fetchAll() as $r)$out[$r['score_type']]=$r;
        return $out;
    }
}
