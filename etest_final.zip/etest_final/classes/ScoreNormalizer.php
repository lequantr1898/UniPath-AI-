<?php
/**
 * ScoreNormalizer — Quy đổi điểm về thang 4.0
 * GPA /10 (VN) · IELTS /9 · TOEFL /120 · SAT /1600 · ACT /36 · GMAT /800 · GRE /340
 */
class ScoreNormalizer {

    public static function normalize(string $type, float $value, string $scale = ''): float {
        return match (strtoupper($type)) {
            'GPA'   => self::gpa($value, $scale),
            'IELTS' => round($value / 9.0 * 4.0, 3),
            'TOEFL' => round($value / 120.0 * 4.0, 3),
            'SAT'   => self::sat($value),
            'ACT'   => self::act($value),
            'GMAT'  => round(($value - 200) / 600 * 4.0, 3),
            'GRE'   => round(($value - 260) / 80 * 4.0, 3),
            default => round($value, 3),
        };
    }

    private static function gpa(float $v, string $scale): float {
        if (str_contains($scale, '10'))  return round($v / 10 * 4, 3);
        if (str_contains($scale, '100')) return round($v / 100 * 4, 3);
        return round(min($v, 4.0), 3);
    }

    private static function sat(float $v): float {
        $table = [
            1570=>4.0, 1540=>3.95, 1510=>3.9, 1480=>3.85, 1450=>3.8,
            1420=>3.75, 1390=>3.7, 1360=>3.65, 1330=>3.6, 1300=>3.55,
            1260=>3.5, 1220=>3.45, 1180=>3.4, 1140=>3.35, 1100=>3.3,
            1060=>3.2, 1010=>3.1, 960=>3.0, 900=>2.8, 400=>2.0,
        ];
        foreach ($table as $threshold => $norm) {
            if ($v >= $threshold) return $norm;
        }
        return 2.0;
    }

    private static function act(float $v): float {
        $table = [
            36=>4.0, 35=>3.97, 34=>3.93, 33=>3.9, 32=>3.87, 31=>3.83,
            30=>3.8, 29=>3.75, 28=>3.7, 27=>3.65, 26=>3.6, 25=>3.55,
            24=>3.5, 22=>3.3, 20=>3.1, 18=>2.9, 1=>2.0,
        ];
        foreach ($table as $threshold => $norm) {
            if ($v >= $threshold) return $norm;
        }
        return 2.0;
    }

    /** Tạo mật khẩu từ họ tên: "Phạm Tuấn Đạt" → "tuandat123" */
    public static function generatePassword(string $fullName): string {
        $parts = preg_split('/\s+/', trim($fullName));
        $given = implode('', array_slice($parts, -2)); // lấy 2 từ cuối
        $ascii = self::removeAccents($given);
        $clean = preg_replace('/[^a-zA-Z]/', '', strtolower($ascii));
        return $clean . '123';
    }

    private static function removeAccents(string $str): string {
        $from = ['à','á','ả','ã','ạ','ă','ắ','ằ','ẳ','ẵ','ặ','â','ấ','ầ','ẩ','ẫ','ậ',
                 'è','é','ẻ','ẽ','ẹ','ê','ế','ề','ể','ễ','ệ',
                 'ì','í','ỉ','ĩ','ị',
                 'ò','ó','ỏ','õ','ọ','ô','ố','ồ','ổ','ỗ','ộ','ơ','ớ','ờ','ở','ỡ','ợ',
                 'ù','ú','ủ','ũ','ụ','ư','ứ','ừ','ử','ữ','ự',
                 'ỳ','ý','ỷ','ỹ','ỵ','đ',
                 'À','Á','Ả','Ã','Ạ','Ă','Ắ','Ằ','Ẳ','Ẵ','Ặ','Â','Ấ','Ầ','Ẩ','Ẫ','Ậ',
                 'È','É','Ẻ','Ẽ','Ẹ','Ê','Ế','Ề','Ể','Ễ','Ệ',
                 'Ì','Í','Ỉ','Ĩ','Ị',
                 'Ò','Ó','Ỏ','Õ','Ọ','Ô','Ố','Ồ','Ổ','Ỗ','Ộ','Ơ','Ớ','Ờ','Ở','Ỡ','Ợ',
                 'Ù','Ú','Ủ','Ũ','Ụ','Ư','Ứ','Ừ','Ử','Ữ','Ự',
                 'Ỳ','Ý','Ỷ','Ỹ','Ỵ','Đ'];
        $to   = ['a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a',
                 'e','e','e','e','e','e','e','e','e','e','e',
                 'i','i','i','i','i',
                 'o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o',
                 'u','u','u','u','u','u','u','u','u','u','u',
                 'y','y','y','y','y','d',
                 'A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A',
                 'E','E','E','E','E','E','E','E','E','E','E',
                 'I','I','I','I','I',
                 'O','O','O','O','O','O','O','O','O','O','O','O','O','O','O','O','O',
                 'U','U','U','U','U','U','U','U','U','U','U',
                 'Y','Y','Y','Y','Y','D'];
        return str_replace($from, $to, $str);
    }
}
