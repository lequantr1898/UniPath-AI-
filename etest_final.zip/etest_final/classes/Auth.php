<?php
require_once __DIR__ . '/../config/Database.php';

/**
 * Auth — Chỉ đăng nhập, không đăng ký.
 * Tài khoản được tạo bởi Admin qua Bulk Import.
 */
class Auth {
    private PDO $conn;

    public function __construct(PDO $conn) {
        $this->conn = $conn;
    }

    /** Đăng nhập — trả về user array hoặc false */
    public function login(string $email, string $password): array|false {
        $stmt = $this->conn->prepare(
            "SELECT id, email, password_hash, role, full_name, is_active
             FROM users WHERE email = :email LIMIT 1"
        );
        $stmt->execute([':email' => trim(strtolower($email))]);
        $user = $stmt->fetch();

        if (!$user || !$user['is_active']) return false;
        if (!password_verify($password, $user['password_hash'])) return false;

        $this->conn->prepare("UPDATE users SET last_login = NOW() WHERE id = :id")
                   ->execute([':id' => $user['id']]);

        unset($user['password_hash']);
        return $user;
    }

    /** Tạo tài khoản (Admin dùng khi import) */
    public function createAccount(string $email, string $password, string $fullName, string $role = 'student'): int|false {
        try {
            $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
            $stmt = $this->conn->prepare(
                "INSERT INTO users (email, password_hash, role, full_name)
                 VALUES (:email, :hash, :role, :name)"
            );
            $stmt->execute([':email' => strtolower($email), ':hash' => $hash, ':role' => $role, ':name' => $fullName]);
            $id = (int)$this->conn->lastInsertId();

            $this->conn->prepare("INSERT INTO student_profiles (user_id) VALUES (:uid)")
                       ->execute([':uid' => $id]);

            return $id;
        } catch (PDOException $e) {
            return false; // email trùng
        }
    }

    public function startSession(array $user): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['uid']    = $user['id'];
        $_SESSION['role']   = $user['role'];
        $_SESSION['name']   = $user['full_name'];
        $_SESSION['email']  = $user['email'];
    }

    public static function check(string $role = ''): bool {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['uid'])) return false;
        if ($role && $_SESSION['role'] !== $role) return false;
        return true;
    }

    public static function requireLogin(string $role = ''): void {
        if (!self::check($role)) {
            header('Location: /login.php');
            exit;
        }
    }

    public static function logout(): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_destroy();
        header('Location: /login.php');
        exit;
    }
}
