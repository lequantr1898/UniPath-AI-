<?php
require_once __DIR__ . '/ScoreNormalizer.php';
require_once __DIR__ . '/Auth.php';

/**
 * BulkImporter — Import học viên từ CSV
 * Tự động tạo tài khoản + mật khẩu = tên123
 */
class BulkImporter {
    private PDO  $conn;
    private Auth $auth;

    public function __construct(PDO $conn) {
        $this->conn = $conn;
        $this->auth = new Auth($conn);
    }

    /**
     * Import từ file CSV
     * @return array {success, failed, duplicates, errors}
     */
    public function importCSV(string $filePath, int $adminId): array {
        if (!file_exists($filePath)) {
            return ['success'=>0,'failed'=>0,'duplicates'=>0,'errors'=>['File not found']];
        }

        $handle  = fopen($filePath, 'r');
        $headers = array_map(fn($h) => strtolower(trim($h)), fgetcsv($handle));

        $ok=0; $fail=0; $dup=0; $errors=[];
        $row=1;

        while (($data = fgetcsv($handle)) !== false) {
            $row++;
            if (count($data) < 2) continue;
            $line = array_combine($headers, array_pad($data, count($headers), ''));

            try {
                $result = $this->processRow($line);
                match($result) {
                    'ok'  => $ok++,
                    'dup' => $dup++,
                    default => ($fail++ && ($errors[] = "Row {$row}: {$result}")),
                };
            } catch (Exception $e) {
                $fail++;
                $errors[] = "Row {$row}: " . $e->getMessage();
            }
        }
        fclose($handle);

        // Ghi log
        $this->conn->prepare(
            "INSERT INTO import_logs (admin_id, filename, total_rows, success_rows, failed_rows, error_details)
             VALUES (:aid, :fn, :tot, :ok, :fail, :err)"
        )->execute([
            ':aid'  => $adminId,
            ':fn'   => basename($filePath),
            ':tot'  => $ok + $fail + $dup,
            ':ok'   => $ok,
            ':fail' => $fail,
            ':err'  => implode("\n", $errors),
        ]);

        return compact('ok', 'fail', 'dup', 'errors');
    }

    private function processRow(array $line): string {
        $name  = $this->col($line, ['ho_ten','full_name','name','họ tên']);
        $email = strtolower(trim($this->col($line, ['email'])));

        if (!$name || !$email) return 'missing_name_email';

        // Kiểm tra trùng email
        $chk = $this->conn->prepare("SELECT id FROM users WHERE email=:e");
        $chk->execute([':e' => $email]);
        if ($chk->fetchColumn()) return 'dup';

        // Tạo mật khẩu tự động: "Phạm Tuấn Đạt" → "tuandat123"
        $password = ScoreNormalizer::generatePassword($name);

        // Tạo tài khoản
        $uid = $this->auth->createAccount($email, $password, $name, 'student');
        if (!$uid) return 'create_failed';

        // Cập nhật profile
        $this->conn->prepare(
            "INSERT INTO student_profiles
               (user_id, gender, dob, phone, nationality, school_name, grade_year)
             VALUES (:uid,:g,:d,:p,:nat,:sc,:gr)
             ON DUPLICATE KEY UPDATE gender=:g, dob=:d, phone=:p, nationality=:nat, school_name=:sc, grade_year=:gr"
        )->execute([
            ':uid' => $uid,
            ':g'   => $this->col($line, ['gioi_tinh','gender']) ?: null,
            ':d'   => $this->parseDate($this->col($line, ['ngay_sinh','dob','birthday'])),
            ':p'   => $this->col($line, ['sdt','phone']) ?: null,
            ':nat' => $this->col($line, ['quoc_tich','nationality']) ?: null,
            ':sc'  => $this->col($line, ['truong_hoc','school','school_name']) ?: null,
            ':gr'  => $this->col($line, ['lop','grade','grade_year']) ?: null,
        ]);

        // Import điểm
        $scoreMap = [
            'GPA'   => [['gpa_10','gpa10','gpa'], '/10'],
            'IELTS' => [['ielts'], '/9.0'],
            'TOEFL' => [['toefl','toefl_ibt'], '/120'],
            'SAT'   => [['sat'], '/1600'],
            'ACT'   => [['act'], '/36'],
        ];

        foreach ($scoreMap as $type => [$keys, $scale]) {
            $raw = $this->col($line, $keys);
            if ($raw !== '' && is_numeric($raw)) {
                $norm = ScoreNormalizer::normalize($type, (float)$raw, $scale);
                $this->conn->prepare(
                    "INSERT INTO student_scores (user_id,score_type,raw_value,raw_scale,norm_value,date_taken)
                     VALUES (:uid,:type,:raw,:scale,:norm,CURDATE())"
                )->execute([':uid'=>$uid,':type'=>$type,':raw'=>(float)$raw,':scale'=>$scale,':norm'=>$norm]);
            }
        }

        return 'ok';
    }

    private function col(array $line, array $keys): string {
        foreach ($keys as $k) {
            if (isset($line[$k]) && trim($line[$k]) !== '') return trim($line[$k]);
        }
        return '';
    }

    private function parseDate(string $v): ?string {
        if (!$v) return null;
        $ts = strtotime($v);
        return $ts ? date('Y-m-d', $ts) : null;
    }

    /** Template CSV mẫu 10 học viên */
    public static function templateCSV(): string {
        $header = 'ho_ten,email,gioi_tinh,ngay_sinh,sdt,truong_hoc,lop,gpa_10,ielts,toefl,sat,act';
        $rows = [
            'Phạm Tuấn Đạt,phamtuandat@gmail.com,Nam,2006-03-15,0912345678,THPT Chuyên Lê Hồng Phong,Lớp 12,8.5,6.5,,,',
            'Nguyễn Thị Lan Anh,nguyenthilananh@gmail.com,Nữ,2006-07-22,0987654321,THPT Chuyên Hùng Vương,Lớp 12,9.1,7.0,,,',
            'Trần Minh Khoa,tranminhkhoa@gmail.com,Nam,2005-11-08,0909090909,THPT Chuyên Nguyễn Huệ,Lớp 12,7.8,6.0,,1150,',
            'Lê Thị Thu Hương,lethithuhuong@gmail.com,Nữ,2006-01-30,0933333333,THPT Marie Curie,Lớp 12,8.9,7.5,,,',
            'Vũ Hoàng Nam,vuhoangnam@gmail.com,Nam,2005-09-14,0944444444,THPT Chuyên Lê Quý Đôn,Lớp 12,8.2,6.0,95,,',
            'Đặng Ngọc Bảo Châu,dangngocdbaochau@gmail.com,Nữ,2006-05-18,0955555555,THPT Chuyên Trần Đại Nghĩa,Lớp 12,9.3,7.5,,,',
            'Bùi Công Thành,buicongthanh@gmail.com,Nam,2005-12-25,0966666666,THPT Chuyên Lê Hồng Phong,Lớp 11,7.5,,80,,',
            'Hoàng Thị Minh Tú,hoangthiminhtu@gmail.com,Nữ,2006-04-10,0977777777,THPT Gia Định,Lớp 12,8.7,6.5,,,',
            'Phan Văn Hải,phanvanhai@gmail.com,Nam,2005-08-03,0988888888,THPT Chuyên Hà Nội Amsterdam,Lớp 12,9.0,7.0,,1300,',
            'Ngô Thị Quỳnh Như,ngothiquynhnhu@gmail.com,Nữ,2006-06-27,0999999999,THPT Chuyên Võ Thị Sáu,Lớp 12,8.4,6.5,,,',
        ];
        return "\xEF\xBB\xBF" . $header . "\n" . implode("\n", $rows) . "\n";
    }
}
