// Web Scraper Template (Node.js)
// YÊU CẦU TRƯỚC KHI CHẠY: Mở terminal và gõ lệnh: npm install cheerio

const cheerio = require('cheerio');
const fs = require('fs');

// Đổi URL này thành trang web tuyển sinh của trường Đại học bạn muốn cào dữ liệu!
const TARGET_URL = 'https://example-university.edu.vn/tuyen-sinh'; 

async function scrapeUniversityData() {
    console.log(`Bắt đầu cào dữ liệu từ: ${TARGET_URL}...`);
    try {
        // 1. Tải toàn bộ mã HTML của trang web
        const response = await fetch(TARGET_URL);
        const html = await response.text();
        
        // 2. Load HTML vào thư viện Cheerio để đọc (giống như jQuery)
        const $ = cheerio.load(html);
        
        const programs = [];

        // 3. Quét qua các hàng trong bảng thông tin ngành học
        // LƯU Ý: Phải sửa lại các class (ví dụ: .major-table tbody tr) cho đúng với web thật
        $('.major-table tbody tr').each((index, element) => {
            const majorName = $(element).find('.major-name').text().trim();
            const majorCode = $(element).find('.major-code').text().trim();
            
            // Xử lý Chỉ tiêu (chuyển chữ thành số)
            const quotaText = $(element).find('.quota').text().trim();
            const quota = parseInt(quotaText, 10);
            
            // Xử lý Tổ hợp môn (Cách nhau bằng dấu phẩy)
            const admissionCombinations = $(element).find('.combinations').text()
                .replace(/\s+/g, '') // xóa khoảng trắng thừa
                .split(',')         // tách thành mảng ["A00", "A01"]
                .filter(Boolean);   // loại bỏ mảng rỗng

            const description = $(element).find('.description').text().trim() || "Chưa có mô tả chi tiết.";

            // Chỉ lấy dữ liệu nếu có Mã Ngành hợp lệ
            if (majorCode) {
                programs.push({
                    major_name: majorName,
                    major_code: majorCode,
                    quota: isNaN(quota) ? null : quota, // Nếu không có chỉ tiêu thì để null
                    admission_combinations: admissionCombinations,
                    description: description
                });
            }
        });

        // 4. Lưu toàn bộ mảng dữ liệu thành file JSON
        const outputPath = 'scraped_admission_data.json';
        fs.writeFileSync(outputPath, JSON.stringify(programs, null, 2), 'utf-8');
        
        console.log(`✅ Xong! Đã lưu thành công ${programs.length} ngành học vào file ${outputPath}!`);
        
    } catch (error) {
        console.error("❌ Lỗi khi cào dữ liệu:", error.message);
    }
}

// Chạy script
scrapeUniversityData();
