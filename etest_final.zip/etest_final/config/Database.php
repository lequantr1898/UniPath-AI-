<?php
class Database {
    private string $host     = 'localhost';
    private string $db_name  = 'etest_db';
    private string $username = 'root';
    private string $password = '';
    private string $charset  = 'utf8mb4';
    public  ?PDO   $conn     = null;

    public function getConnection(): ?PDO {
        if ($this->conn !== null) return $this->conn;
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->db_name};charset={$this->charset}";
            $this->conn = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            error_log('DB Error: ' . $e->getMessage());
            die(json_encode(['error' => 'Database connection failed.']));
        }
        return $this->conn;
    }
}
