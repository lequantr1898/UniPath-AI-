'use strict';

require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path    = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'changeme',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true if using HTTPS
}));

// API Routes
app.use('/api/auth',     require('./src/routes/auth'));
app.use('/api/students', require('./src/routes/students'));
app.use('/api/import',   require('./src/routes/import'));
app.use('/api/ai',       require('./src/routes/ai'));
app.use('/api/majors',   require('./src/routes/majors'));

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// Catch-all for API 404
app.all('/api/*', (req, res) => {
  res.status(404).json({ error: 'API endpoint not found' });
});

// Fallback to index.html for unknown frontend routes (SPA behavior if needed)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
